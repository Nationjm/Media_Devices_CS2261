#ifndef MOVINGMOUNTAINS_H
#define MOVINGMOUNTAINS_H

#define MOVINGMOUNTAINS_WIDTH  (64)
#define MOVINGMOUNTAINS_HEIGHT (32)
#define MovingMountainsMapLen (4096)

extern const unsigned short MovingMountainsMap[2048];

#endif
