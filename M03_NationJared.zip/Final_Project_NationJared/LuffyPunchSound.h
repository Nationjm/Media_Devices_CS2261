// LuffyPunchSound sound made by wav2c

extern const unsigned int LuffyPunchSound_sampleRate;
extern const unsigned int LuffyPunchSound_length;
extern const signed char LuffyPunchSound_data[];
