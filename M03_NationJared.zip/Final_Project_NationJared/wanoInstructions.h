
//{{BLOCK(wanoInstructions)

//======================================================================
//
//	wanoInstructions, 240x160@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 38400 = 38912
//
//	Time-stamp: 2023-11-13, 14:48:05
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_WANOINSTRUCTIONS_H
#define GRIT_WANOINSTRUCTIONS_H

#define wanoInstructionsBitmapLen 38400
extern const unsigned short wanoInstructionsBitmap[19200];

#define wanoInstructionsPalLen 512
extern const unsigned short wanoInstructionsPal[256];

#endif // GRIT_WANOINSTRUCTIONS_H

//}}BLOCK(wanoInstructions)
