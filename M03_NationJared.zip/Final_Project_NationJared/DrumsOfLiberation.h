// DrumsOfLiberation sound made by wav2c

extern const unsigned int DrumsOfLiberation_sampleRate;
extern const unsigned int DrumsOfLiberation_length;
extern const signed char DrumsOfLiberation_data[];
