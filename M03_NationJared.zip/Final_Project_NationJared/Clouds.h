#ifndef CLOUDS_H
#define CLOUDS_H

#define CLOUDS_WIDTH  (64)
#define CLOUDS_HEIGHT (32)
#define CloudsMapLen (4096)

extern const unsigned short CloudsMap[2048];

#endif
