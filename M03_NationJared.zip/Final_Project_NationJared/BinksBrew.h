// BinksBrew sound made by wav2c

extern const unsigned int BinksBrew_sampleRate;
extern const unsigned int BinksBrew_length;
extern const signed char BinksBrew_data[];
