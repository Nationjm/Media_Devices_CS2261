#ifndef ROOFTOPGROUNDBACKGROUND_H
#define ROOFTOPGROUNDBACKGROUND_H

#define ROOFTOPGROUNDBACKGROUND_WIDTH  (32)
#define ROOFTOPGROUNDBACKGROUND_HEIGHT (32)
#define RooftopGroundBackgroundMapLen (2048)

extern const unsigned short RooftopGroundBackgroundMap[1024];

#endif
