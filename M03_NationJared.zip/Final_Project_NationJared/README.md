# Milestone 1 Notes
I think there is a possibility I may have laid out more than I can complete in a month. <br>
I still want to attempt to implement everything from my milestone 0, but I am going to <br>
prioritize the main fight between Luffy and dragon Kaido first and add the other fights <br>
if I have time to. If I only implement the fight between dragon form Kaido and Luffy, <br> 
my cheat will be entering gear 5 and being able to bounce Kaido's fireballs back at him. <br>
If I am able to implement the entire game how I want, the cheat will be that the player's <br>
attack doubles in damage.