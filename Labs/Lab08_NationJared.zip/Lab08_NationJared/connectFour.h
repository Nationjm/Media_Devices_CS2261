
//{{BLOCK(connectFour)

//======================================================================
//
//	connectFour, 40x24@4, 
//	+ palette 256 entries, not compressed
//	+ 15 tiles not compressed
//	Total size: 512 + 480 = 992
//
//	Time-stamp: 2023-10-18, 20:44:11
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_CONNECTFOUR_H
#define GRIT_CONNECTFOUR_H

#define connectFourTilesLen 480
extern const unsigned short connectFourTiles[240];

#define connectFourPalLen 512
extern const unsigned short connectFourPal[256];

#endif // GRIT_CONNECTFOUR_H

//}}BLOCK(connectFour)
