#ifndef CONNECTFOURTILED_H
#define CONNECTFOURTILED_H

#define CONNECTFOURTILED_WIDTH  (32)
#define CONNECTFOURTILED_HEIGHT (32)
#define connectFourTiledMapLen (2048)

extern const unsigned short connectFourTiledMap[1024];

#endif
