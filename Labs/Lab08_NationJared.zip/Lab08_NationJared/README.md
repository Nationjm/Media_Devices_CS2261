CONNECT FOUR!

Controls:
- START: Restart game
- LEFT: Move chip to the left
- RIGHT: Move chip to the right
- DOWN: Place chip in grid