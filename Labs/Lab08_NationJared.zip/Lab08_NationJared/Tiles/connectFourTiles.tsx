<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="connectFour" tilewidth="8" tileheight="8" tilecount="5" columns="5">
 <image source="connectFour.bmp" width="40" height="8"/>
</tileset>
