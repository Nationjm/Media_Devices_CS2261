#ifndef CONNECTFOURTILEMAP_H
#define CONNECTFOURTILEMAP_H

#define CONNECTFOURTILEMAP_WIDTH  (32)
#define CONNECTFOURTILEMAP_HEIGHT (32)
#define connectFourTilemapMapLen (2048)

extern const unsigned short connectFourTilemapMap[1024];

#endif
