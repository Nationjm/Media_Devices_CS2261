typedef struct {
    int tileID;
    int winTextPaletteRow;
    int spritePaletteRow;

} CHIP;

void initGame();
void updateGame();
void drawGame();