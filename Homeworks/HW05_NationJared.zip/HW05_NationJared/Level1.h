#ifndef LEVEL1_H
#define LEVEL1_H

#define LEVEL1_WIDTH  (32)
#define LEVEL1_HEIGHT (32)
#define Level1MapLen (2048)

extern const unsigned short Level1Map[1024];

#endif
