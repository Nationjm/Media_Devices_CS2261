# Bubble Bobble
## Controls
Move the player back and forth using the left and right buttons. <br>
Press the up button to jump. Press A to shoot a bubble <br>
When in the win or lose state, press the left shoulder to re-enter the START state <br>

## Issues with my code
During the first game state, the player will only appear after shooting the first bubble <br>
Lives are implemented but they do not have a visual representation <br>
