
//{{BLOCK(Level1CollisionBitmap)

//======================================================================
//
//	Level1CollisionBitmap, 256x256@8, 
//	+ bitmap not compressed
//	Total size: 65536 = 65536
//
//	Time-stamp: 2023-10-30, 14:44:17
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL1COLLISIONBITMAP_H
#define GRIT_LEVEL1COLLISIONBITMAP_H

#define Level1CollisionBitmapBitmapLen 65536
extern const unsigned char Level1CollisionBitmapBitmap[65536];

#endif // GRIT_LEVEL1COLLISIONBITMAP_H

//}}BLOCK(Level1CollisionBitmap)
