#ifndef LEVEL1MAP_H
#define LEVEL1MAP_H

#define LEVEL1MAP_WIDTH  (32)
#define LEVEL1MAP_HEIGHT (32)
#define Level1MapMapLen (2048)

extern const unsigned short Level1MapMap[1024];

#endif
