
//{{BLOCK(BubbleBobbleTitle)

//======================================================================
//
//	BubbleBobbleTitle, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 261 tiles (t reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 8352 + 2048 = 10912
//
//	Time-stamp: 2023-10-30, 20:03:02
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_BUBBLEBOBBLETITLE_H
#define GRIT_BUBBLEBOBBLETITLE_H

#define BubbleBobbleTitleTilesLen 8352
extern const unsigned short BubbleBobbleTitleTiles[4176];

#define BubbleBobbleTitleMapLen 2048
extern const unsigned short BubbleBobbleTitleMap[1024];

#define BubbleBobbleTitlePalLen 512
extern const unsigned short BubbleBobbleTitlePal[256];

#endif // GRIT_BUBBLEBOBBLETITLE_H

//}}BLOCK(BubbleBobbleTitle)
