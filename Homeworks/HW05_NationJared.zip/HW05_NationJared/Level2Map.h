#ifndef LEVEL2MAP_H
#define LEVEL2MAP_H

#define LEVEL2MAP_WIDTH  (32)
#define LEVEL2MAP_HEIGHT (32)
#define Level2MapMapLen (2048)

extern const unsigned short Level2MapMap[1024];

#endif
