<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="World Tiles" tilewidth="8" tileheight="8" tilecount="144" columns="12">
 <image source="TilesBitmap.bmp" width="100" height="100"/>
</tileset>
