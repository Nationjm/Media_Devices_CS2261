
//{{BLOCK(Level2CollisionBitmap)

//======================================================================
//
//	Level2CollisionBitmap, 256x256@8, 
//	+ bitmap not compressed
//	Total size: 65536 = 65536
//
//	Time-stamp: 2023-10-30, 14:38:25
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL2COLLISIONBITMAP_H
#define GRIT_LEVEL2COLLISIONBITMAP_H

#define Level2CollisionBitmapBitmapLen 65536
extern const unsigned char Level2CollisionBitmapBitmap[65536];

#endif // GRIT_LEVEL2COLLISIONBITMAP_H

//}}BLOCK(Level2CollisionBitmap)
